<?php

require_once '../includes/models.php';

logout();

redirectTo('login.php');
